'use strict'

function search(input, target) {
  return input.indexOf(target);  // Remove this line and change to your own algorithm
}

module.exports = search
